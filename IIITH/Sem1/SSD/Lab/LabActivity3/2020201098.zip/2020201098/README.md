#  Lab Activity 3


## HTML
used `<ul` and `li` tags for unordere lists.

used `meta` tag with field viewport for responsive design.


## CSS
Used both internal and external css


## Javascript

Used external Javascript for displaying current date with respect to the current location.

`Date()` function for getting the current date.
