# AOS Assignment 1

* I have assumed the path to be space free
* We can avoid that by typing the path in quotes but I haven't implemented yet.

