char = input()
char = char.lower()
if char =='a' or char =='e' or  char =='i' or char =='o' or char=='u' :
    print("Vowel")
else:
    print("Not vowel")
