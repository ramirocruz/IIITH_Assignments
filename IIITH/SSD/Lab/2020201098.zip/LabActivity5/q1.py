num1,num2=input().split()

if float(num1) < float(num2) :
    m=num2
else:
    m=num1
print(m)