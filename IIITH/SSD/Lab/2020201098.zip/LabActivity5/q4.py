char_input=input()
for i in reversed(char_input):
    print(i,end="")
print("")
