# Lab Activity 5 (Python)

## Q1
* You need to enter the two inputs in one line with space.

## Q2
* It will give false for any invalid input.

## Q3
* I am assuming the input as `word1 ,  word2 , word3,....` The `,` is must but any number of  space can be given, no worries.
* The output is the of the list of count of each word

## Q4
* Taking an input and running the for loop in reverse order.

