Lab Activity 4
=================

## Q1

* Used html select tag for the dropdown
* Used input fields to append data to the dropdown.


## Q2
* Using a button to toggle between two images.

## Q3
* User can enter any value in the text and it will be later deleted.
* Using keyup event is used to capture the key stroke.


## Q4
* Using `setInterval()` for calling function in intervals.
* Using css opacity to hide and show the text.
