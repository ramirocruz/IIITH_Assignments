//creating a dropdown using JQuery

$("#drop").append($(`<select id="sub">
  <option selected disabled>Subjects</option> 
<option value="mat">Maths</option>
<option value="eng">English</option>
<option value="ssd">SSD</option>
<option value="aos">AOS</option>
<option value="dsa">DSA</option>
</select> `));


$("#drop-btn").on("click",function(){
  console.log("hello");
  let text=$("#txt").val();
  let values=$("#values").val();
  if(text==="" || values==="")
    alert("enter a valid info");
  else{
  console.log(text + values);
  $("#sub").append($(`<option value="${values}">${text}</option>`))
  }
  $("#txt").val("");
  $("#values").val("");
});

//Change background
var toggle=true;
$("#bg-btn").on("click",function(){
  
  if(toggle){
  $("html").css("background-image", "url('httyd.jpg')");
  toggle=false;
  }
  else
    {
      $("html").css("background-image", "url('kyoma.png')");
      toggle=true;
    }
})

//Detect 3
$("#keyd").on("keyup",function(e){
  $(this).val("");
  if(e.which==51 || e.which==99)
    {
      
      alert("3 is pressed");
      
    }
  
  
})


//Blinking Text
var toggle2=true;
setInterval(function(){
  if(toggle2)
  {$("#blink").css("opacity","0%")
  toggle2=false;}
  else
  { $("#blink").css("opacity","100%")
  toggle2=true;}
  
},1000);
