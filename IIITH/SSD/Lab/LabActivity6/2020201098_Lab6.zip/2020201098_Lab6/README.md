# SSD Lab Activity 6

# Question 1
* The delimeter is semicolon

# Question 2
* The program will work for non alpha strings also

# Question 3
* I have assumed comma separated string inputs
* Used the lambda function in filtering the suitable words
* Then used loop to count the total lenth

# Question 4
* I have assumed comma separated string inputs.
* Then I have used filter function with lambda to filter out numbers not divisible by 5
* I have given output of a set containing all the sequences
