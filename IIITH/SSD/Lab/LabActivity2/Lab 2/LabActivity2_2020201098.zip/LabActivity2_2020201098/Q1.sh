cat $1| awk '/^s[^a]/ {print $1}'

