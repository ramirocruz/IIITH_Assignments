sed 's/ ./#5g' $1
