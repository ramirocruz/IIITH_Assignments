# Activity 2
## Q1
I am assuming that a line has only one word of matching.



## Git Activity
I am not using space in the folder names.

* Github link [Lab Acitivity 2](https://github.com/ramirocruz/SSD-Lab-Activity-2)
* Created a repo with name SSD Lab Activity 2.
* `git clone https://github.com/ramirocruz/SSD-Lab-Activity-2.git`
* go to the directory and `mkdir LabActivity2`
* go to the directory and create a README.md file
* `git add README.md`
* git commit -m "Add README.md"
* `touch hello_world.txt` created a new file in the directory.
* modified README.md with **"This is my first git project"**.
* `git add hello_world.txt`
* `git commit -m "Add hello_world.txt and edit README.md"`
* `git push origin master`
* `git checkout -b NewBranch`
* `touch test.txt`
* `git add .`
* `git commit -m "added test.txt"`
* `git push origin NewBranch`
* create pull request from Github and merge the repository
* `git checkout master`
* `git merge NewBranch`
* `git branch NewBranch -D`
