# Assignment 2 
## I have made a fictional biodata about myself being a chairman of a mythical hunter association which helps the people.

### Library Used:
* JQuery
* Font Awesome
* One Google Font
* Bootstrap (Just for the cool look of Navbar)

### Note:
* All the functionality of Navbar is done by me plus most of the css also.
* I first made Bootstrap Navbar, but later removed the bootstrap classes and made my own navbar.
* After finalising all the work when I tried to remove bootstrap cdn it the navbar become a little uncool.
* Therefore I have kept the cdn.


### JS functionality implemented:
* Made the navbar toggle hide/show button
* Also added some content show/hide button
* and the button icon will also change

### Hosting address:
* Github: "https://ramirocruz.github.io/ssdass2/"
