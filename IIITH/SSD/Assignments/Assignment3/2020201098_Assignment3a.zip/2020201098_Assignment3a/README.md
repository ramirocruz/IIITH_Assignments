# Assignment 3 part 1

# Q1
* I have modified the json to map parent with id rather than name since id is unique.
* The json file will have one more field for each employee named eid
* The parent will also be mapped with id and not name.
* I have outputed both id and name in appropriate positions.
* I have used dictionaries to map parents, levels and names

# Q2
* I have used full gregorian calendar.
* I am first calculating total days in a date and then subtracting the days from the two dates.

# Q3
* I am sorting the intervals and then finding the merged intervals with appropriate duration.
* To sort I am using compare function which calculates different between two times.
* Then I have converted this compare function to key for the sort function

## Github link:
`https://github.com/ramirocruz/2020201098_Assignment3a`

