### IAS LAB 1
* `server.py` and `client.py` are the files to check with each other
* `server_browser.py` is the server file for the browser
* The port number is hardcoded in the source code in the `PORT` variable
