import flask
import requests
import threading

main_server = "http://localhost:8888"
sensors = {}
time_interval = 5
app = flask.Flask(__name__)
@app.route('/',methods = ["POST"])
def index():
    global sensors
    content = flask.request.json
    sensors[str(content["id"])] = content["val"]
    return flask.Response(status=200)

def check_req():
    global sensors
    print(sensors)
    try:
        res = requests.get(main_server+"/req")
        if(res.ok):
            res = res.json()
            print(res)
            print(sensors)
            status = "ok"
            print(status)
            try:
                # global sensors
                sensor_id = str(res["id"])
                print(sensors)
                print(sensor_id)
                # print(sensor_id + " here"+sensors[sensor_id])
                requests.post(main_server+"/res",json={"status":status,"sensor":"ok"})
            except KeyError:
                status = "not valid id"
                print(status)
                requests.post(main_server+"/res",json={"status":status,"sensor":None})
            except TypeError:
                print("TypeError")
                pass
    except:
        print("##")
        pass
        

check_req()


if(__name__ == "__main__"):
    app.run(port="18000",debug=True)
