## Assignment 2 Merge Sort
* there are two python as well as bash files for each of those python files.
* One file is for normal execution of program and other is for threaded execution of the program.
* ./sort.sh inputfile.txt outputfile.txt `memorylimit` `order` `column list`
* ./sort_th.sh inputfile.txt outputfile.txt `memorylimit` `number of threads` `order` `column list`