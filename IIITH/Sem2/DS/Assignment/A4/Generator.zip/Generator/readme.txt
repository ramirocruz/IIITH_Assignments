How to run ?
Usage: java -jar JoinGenerator.jar noofrecordsinR noofrecordsinS sizeofX sizeofY sizeofZ

Output:
Two files will be generated inputR and the inputS
column data separated by a single space.
