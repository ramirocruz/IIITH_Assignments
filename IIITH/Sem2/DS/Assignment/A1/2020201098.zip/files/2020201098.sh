
python engine.py "$1"
